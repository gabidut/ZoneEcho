package fr.site19.mod.objects.blocks.stairs;

import fr.site19.mod.Main;
import fr.site19.mod.init.BlockInit;
import fr.site19.mod.init.ItemInit;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemBlock;

import java.util.Objects;

public class BlockStairs extends net.minecraft.block.BlockStairs {
    public BlockStairs(String name, IBlockState modelState) {
        super(modelState);
        setUnlocalizedName(name);
        setRegistryName(name);
        setCreativeTab(Main.SITE19_UTILS);

        BlockInit.BLOCKS.add(this);
        ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(Objects.requireNonNull(this.getRegistryName())));
    }
}
