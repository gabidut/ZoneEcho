package fr.site19.mod.objects.items;

import fr.site19.mod.Main;
import fr.site19.mod.init.ItemInit;
import fr.site19.mod.util.interfaces.IHasModel;

import net.minecraft.item.Item;

public class ItemBase extends Item implements IHasModel {
    public ItemBase(String name)
    {
        setUnlocalizedName(name);
        setRegistryName(name);
        setCreativeTab(Main.SITE19_TAB);
        ItemInit.ITEMS.add(this);
    }



    @Override
    public void registerModels() {
        Main.proxy.registerItemRenderer(this, 0);
    }
}
