package fr.site19.mod.util.command;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

public class CommandDev extends CommandBase {

    public static final Minecraft MC = Minecraft.getMinecraft();


    @Override
    public String getName() {
        return "testcommand";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "testcommand";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {

        sender.sendMessage(new TextComponentString(MC.getConnection().getPlayerInfoMap().size() + "/" + MC.getConnection().currentServerMaxPlayers + " joueurs"));

    }
}