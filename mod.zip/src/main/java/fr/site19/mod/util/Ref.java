package fr.site19.mod.util;

public class Ref
{
    public static final String MODID = "site19";
    public static final String NAME = "Mod Site19";
    public static final String VERSION = "V1.1D";
    public static final String CLIENT = "fr.site19.mod.proxy.ClientProxy";
    public static final String COMMON = "fr.site19.mod.proxy.CommonProxy";



}
