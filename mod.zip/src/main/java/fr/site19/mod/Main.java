package fr.site19.mod;


import fr.site19.mod.proxy.CommonProxy;
import fr.site19.mod.tabs.MainTab;
import fr.site19.mod.util.Ref;
import net.minecraft.block.BlockDoor;
import net.minecraft.client.Minecraft;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import org.apache.logging.log4j.Logger;

// @DynamXAddon(modid = Ref.MODID, name = "OceanRPAddon", version = Ref.VERSION)
@Mod(modid = Ref.MODID, name = Ref.NAME, version = Ref.VERSION)
@Mod.EventBusSubscriber(modid = Ref.MODID)
public class Main {
    public static final CreativeTabs SITE19_TAB = new MainTab("site19");
    public static final CreativeTabs SITE19_UTILS = new MainTab("utils");



    @SidedProxy(clientSide = Ref.CLIENT, serverSide = Ref.COMMON)
    public static CommonProxy proxy;
    public static SimpleNetworkWrapper network;
    public static Logger logger;

    @Mod.EventHandler
    public static void preInit(FMLPreInitializationEvent e) {
        logger = e.getModLog();
        proxy.preInit();

    }
    // @DynamXAddon.AddonEventSubscriber
    // public static void init{System.out.println("Hello world !");};
    @Mod.EventHandler
    public static void init(FMLInitializationEvent e) {}

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {}

}


