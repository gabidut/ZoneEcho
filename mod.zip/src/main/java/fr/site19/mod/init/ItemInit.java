package fr.site19.mod.init;

import fr.site19.mod.objects.items.ItemBase;
import net.minecraft.item.Item;

import java.util.ArrayList;
import java.util.List;

public class ItemInit
{
    public static List<Item> ITEMS = new ArrayList<Item>();

    //Autres
    public static final Item Logo = new ItemBase("logo");


}
